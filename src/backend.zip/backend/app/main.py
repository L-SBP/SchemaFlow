# src/backend/app/main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="AI Database Platform - Chat Module",
    description="AI-powered database deployment and table generation - Chat Backend API",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Chat API endpoints
@app.post("/api/v1/chat/chat")
async def chat_with_ai():
    return {
        "response": "Chat backend is working! Demo response.",
        "sql_generated": "SELECT * FROM users WHERE status = 'active'",
        "requires_confirmation": False,
        "statement_type": "SELECT",
        "statement_id": 1
    }

@app.get("/api/v1/chat/sessions/{session_id}/messages")
async def get_session_messages(session_id: int):
    return {
        "session_id": session_id,
        "messages": [
            {
                "message_id": 1,
                "message_type": "user",
                "content": "Show all active users",
                "requires_confirmation": False,
                "user_confirmed": None
            }
        ],
        "total_count": 1
    }

@app.post("/api/v1/chat/sessions")
async def create_session():
    return {
        "session_id": 1,
        "session_name": "New Session",
        "created_at": "2024-01-01T10:00:00Z",
        "last_activity": "2024-01-01T10:00:00Z"
    }

@app.get("/")
async def root():
    return {"message": "AI Database Platform Chat API Service is Running"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "chat-backend"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001, reload=True)